// App.js hoặc một file khác nơi bạn muốn sử dụng MyComponent
import React from 'react';
import Re from './re'; // Đường dẫn phải chính xác đến file MyComponent

const App = () => {
  return (
    <div>
      <Re />
    </div>
  );
};

export default App;